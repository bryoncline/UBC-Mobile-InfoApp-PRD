﻿//
//
//

function buttonOnClick() {
    alert("onclick pressed");
}